import requests 

req_session = requests.Session()    